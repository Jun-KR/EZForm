<?php

namespace JUNKR;

use pocketmine\plugin\PluginBase;

class EZForm extends PluginBase{
    
}
